/**
 * DIGIMAN.ID — Halaman utama (server component).
 * Seluruh konten dibaca dari database (getSiteData + blog + Gunara OS),
 * lalu dirender via AppRouter: landing multi-seksi + view hash (#/os, #/blog,
 * #/blog/{slug}, #/proposal, #/admin) dalam satu route "/".
 */
import { getSiteData } from "@/lib/digiman-data";
import { db } from "@/lib/db";
import { parseBlogCard } from "@/lib/blog-types";
import type { BlogCardData } from "@/lib/blog-types";
import type { GunaraPackageData } from "@/lib/gunara";
import AppRouter from "@/components/digiman/app-router";
import { LocaleProvider } from "@/lib/i18n";

export const dynamic = "force-dynamic";

function jsonArr(raw: string | null | undefined): string[] {
  try {
    const v: unknown = JSON.parse(raw ?? "[]");
    return Array.isArray(v) ? v.map((x) => String(x)) : [];
  } catch {
    return [];
  }
}

export default async function Page() {
  const { settings, services, testimonials, faqs, offices } = await getSiteData();

  // Data fitur baru — gagal aman: landing tetap tampil tanpa teaser.
  let blogPosts: BlogCardData[] = [];
  let packages: GunaraPackageData[] = [];
  let domainCount = 0;
  let docCount = 0;
  try {
    const [rows, pkgs, dc, tc] = await Promise.all([
      db.blogPost.findMany({
        where: { published: true },
        orderBy: [{ publishedAt: "desc" }, { createdAt: "desc" }],
        take: 3,
      }),
      db.gunaraPackage.findMany({
        where: { active: true },
        orderBy: { order: "asc" },
      }),
      db.pgaDomain.count(),
      db.pgaDocument.count(),
    ]);
    blogPosts = rows.map(parseBlogCard);
    packages = pkgs.map((p) => ({
      code: p.code,
      name: p.name,
      tagline: p.tagline,
      description: p.description,
      docCount: p.docCount,
      price: p.price,
      durationWeeks: p.durationWeeks,
      features: jsonArr(p.features),
      documentCodes: jsonArr(p.documentCodes),
      highlight: p.highlight,
      order: p.order,
    }));
    domainCount = dc;
    docCount = tc;
  } catch {
    // fallback: teaser disembunyikan, situs tetap hidup
  }

  // ── SEO GOD MODE: JSON-LD level halaman ──────────────────────────────
  // Digabung ke entity graph (layout.tsx) via @id yang sama:
  //   • FAQPage   → rich result tanya-jawab di SERP
  //   • Review + AggregateRating dari testimoni asli → bintang di SERP
  //   • ItemList seluruh layanan → pemetaan katalog di mesin pencari
  const ratingVals = testimonials
    .map((tst) => Number(tst.rating) || 0)
    .filter((r) => r > 0);
  const ratingAvg =
    ratingVals.length > 0
      ? ratingVals.reduce((a, b) => a + b, 0) / ratingVals.length
      : 0;

  const PAGE_JSON_LD = {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "FAQPage",
        "@id": "https://digiman.id/#faq-halaman",
        isPartOf: { "@id": "https://digiman.id/#website" },
        mainEntity: faqs
          .slice(0, 20)
          .map((f) => ({
            "@type": "Question",
            name: f.q,
            acceptedAnswer: { "@type": "Answer", text: f.a },
          })),
      },
      {
        // Node pelengkap untuk @id "#layanan-bisnis" yang sudah didefinisikan
        // di layout.tsx — mesin pencari menggabungkan propertinya otomatis.
        "@type": "ProfessionalService",
        "@id": "https://digiman.id/#layanan-bisnis",
        aggregateRating:
          ratingAvg > 0
            ? {
                "@type": "AggregateRating",
                ratingValue: ratingAvg.toFixed(1),
                reviewCount: ratingVals.length,
                bestRating: 5,
                worstRating: 1,
              }
            : undefined,
        review: testimonials.slice(0, 3).map((tst) => ({
          "@type": "Review",
          author: { "@type": "Person", name: tst.name },
          reviewRating: {
            "@type": "Rating",
            ratingValue: Number(tst.rating) || 5,
            bestRating: 5,
          },
          reviewBody: tst.text,
        })),
      },
      {
        "@type": "ItemList",
        "@id": "https://digiman.id/#katalog-layanan",
        name: "Katalog Layanan DIGIMAN.ID",
        numberOfItems: services.length,
        itemListElement: services.map((svc, i) => ({
          "@type": "ListItem",
          position: i + 1,
          item: {
            "@type": "Service",
            name: svc.title,
            provider: { "@id": "https://digiman.id/#organisasi" },
            areaServed: { "@type": "Country", name: "Indonesia" },
          },
        })),
      },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(PAGE_JSON_LD).replace(/</g, "\\u003c"),
        }}
      />
      <LocaleProvider>
        <AppRouter
          settings={settings}
          services={services}
          testimonials={testimonials}
          faqs={faqs}
          offices={offices}
          blogPosts={blogPosts}
          packages={packages}
          domainCount={domainCount}
          docCount={docCount}
        />
      </LocaleProvider>
    </>
  );
}
